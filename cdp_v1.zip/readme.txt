PCB fabrication order
---------------------
Single panel, 2-layer prototype (Base price: $99)

Billing and shipping address:
    Michael Price
    24 Portsmouth St.
    Cambridge MA 02141-1328

Specifications
--------------
Part number:            cdp_v1
Panel size:             9.658" x 13.698" (132.3 in^2)
Number of layers:       2
Minimum trace width:    0.009"
Minimum spacing:        0.006" (+$20 upgrade)
Minimum drill size:     0.022"
Multi-project panel:    Yes (+$30 upgrade)
Silkscreen:             White, both sides (+$20 upgrade)
Solder mask:            Green, both sides
Copper thickness:       1 oz.
Board material:         0.062" FR4

Supplied CAM files:

Filename            Description         Format
--------            -----------         ------
cdp_v1.plc          Top silkscreen      Gerber RS274X
cdp_v1.pls          Bottom silkscreen   Gerber RS274X
cdp_v1.cmp          Top copper          Gerber RS274X
cdp_v1.sol          Bottom copper       Gerber RS274X
cdp_v1.stc          Top soldermask      Gerber RS274X
cdp_v1.sts          Bottom soldermask   Gerber RS274X
cdp_v1.drl          List of drills      Plain text
cdp_v1.drd          Drill placements    Excellon (inches, 2.4)
